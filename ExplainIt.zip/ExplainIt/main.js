/**
 * ExplainIt AI - Main JavaScript logic
 */

document.addEventListener('DOMContentLoaded', () => {
    const explainBtn = document.getElementById('explainBtn');
    const inputText = document.getElementById('inputText');
    const loadingIndicator = document.getElementById('loadingIndicator');
    const resultsContainer = document.getElementById('resultsContainer');
    const errorMessage = document.getElementById('errorMessage');

    // Output Elements
    const summaryContent = document.getElementById('summaryContent');
    const mainExplanationContent = document.getElementById('mainExplanationContent');
    const keyConceptsContent = document.getElementById('keyConceptsContent');
    const whyMattersContent = document.getElementById('whyMattersContent');
    const takeawaysContent = document.getElementById('takeawaysContent');

    explainBtn.addEventListener('click', handleExplain);

    async function handleExplain() {
        const text = inputText.value.trim();

        // 1. Validation
        if (!text) {
            showError("Please enter some text to explain.");
            return;
        }

        if (text.length < 10) {
            showError("Text is too short. Please provide more context.");
            return;
        }

        if (text.length > 5000) {
            showError("Text is too long (Max 5,000 characters). Please shorten it.");
            return;
        }

        // 2. Reset State
        hideError();
        resultsContainer.style.display = 'none';
        loadingIndicator.style.display = 'block';
        explainBtn.disabled = true;
        explainBtn.textContent = 'Analyzing...';

        try {
            // 3. API Request
            const response = await fetch('api/explain.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ content: text })
            });

            const data = await response.json();

            if (!response.ok) {
                console.error('API Error Details:', data);
                // Check if there's a detailed error message from Gemini
                const detailMsg = data.details && data.details.error && data.details.error.message 
                    ? data.details.error.message 
                    : (data.error || 'Failed to get explanation');
                throw new Error(detailMsg);
            }

            // Check for functional error returned by AI (safety check)
            if (data.error) {
                throw new Error(data.error);
            }

            // 4. Render Results
            renderResults(data);

        } catch (error) {
            console.error('Error:', error);
            showError(error.message || "An unexpected error occurred. Please try again.");
        } finally {
            loadingIndicator.style.display = 'none';
            explainBtn.disabled = false;
            explainBtn.textContent = 'Explain This';
        }
    }

    function renderResults(data) {
        // Clear previous results
        const detectedTypeBadge = document.getElementById('detectedTypeBadge');
        summaryContent.innerHTML = '';
        mainExplanationContent.innerHTML = '';
        keyConceptsContent.innerHTML = '';
        whyMattersContent.innerHTML = '';
        takeawaysContent.innerHTML = '';

        // 0. Detected Type
        if (data.detected_type) {
            detectedTypeBadge.textContent = "Detected: " + data.detected_type;
            detectedTypeBadge.style.display = 'inline-block';
        } else {
            detectedTypeBadge.style.display = 'none';
        }

        // 1. Simple Summary
        if (data.summary) {
            const p = document.createElement('p');
            p.textContent = data.summary;
            summaryContent.appendChild(p);
        }

        // 2. Main Explanation
        if (data.main_explanation) {
            const p = document.createElement('p');
            p.textContent = data.main_explanation;
            mainExplanationContent.appendChild(p);
        }

        // 3. Key Concepts
        if (data.key_concepts && Array.isArray(data.key_concepts)) {
            data.key_concepts.forEach(concept => {
                const div = document.createElement('div');
                div.className = 'concept-item';
                
                const term = document.createElement('span');
                term.className = 'concept-term';
                term.textContent = concept.term;

                const def = document.createElement('span');
                def.textContent = concept.definition;

                div.appendChild(term);
                div.appendChild(document.createTextNode(': ')); // Visual separator
                div.appendChild(def);
                keyConceptsContent.appendChild(div);
            });
        }

        // 3. Why It Matters
        if (data.why_matters) {
            const p = document.createElement('p');
            p.textContent = data.why_matters;
            whyMattersContent.appendChild(p);
        }

        // 4. Actionable Takeaways
        if (data.takeaways && Array.isArray(data.takeaways)) {
            data.takeaways.forEach(takeway => {
                const li = document.createElement('li');
                li.textContent = takeway;
                takeawaysContent.appendChild(li);
            });
        }

        // Show container with animation
        resultsContainer.style.display = 'flex';
        
        // Scroll to results
        resultsContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function showError(msg) {
        errorMessage.textContent = msg;
        errorMessage.style.display = 'block';
    }

    function hideError() {
        errorMessage.style.display = 'none';
    }
});
