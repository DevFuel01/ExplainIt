<?php
// api/explain.php

// Enable CORS for development (or specify allowed origins in production)
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once 'config.php';

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
    exit;
}

// Get raw POST data
$data = json_decode(file_get_contents("php://input"));

// Validate input
if (empty($data->content)) {
    http_response_code(400);
    echo json_encode(['error' => 'No content provided.']);
    exit;
}

if (strlen($data->content) > 5000) {
    http_response_code(400);
    echo json_encode(['error' => 'Content exceeds maximum limit of 5,000 characters.']);
    exit;
}

$userContent = trim($data->content);

// Rate limiting (Basic implementation: check last submission time from same IP - skipped for hackathon simplicity, relying on Gemini API limits)

// Prepare system prompt for Gemini
$systemPrompt = "You are ExplainIt AI, an expert at breaking down complex topics into clear, understandable explanations.
Your task is to analyze the provided text and output a JSON object with the following structure:
{
  \"detected_type\": \"One of: 'Legal Document', 'Source Code', 'Technical Documentation', 'Article', 'General Text'\",
  \"main_explanation\": \"A clear, educational explanation of the topic. If code, explain the logic. If legal, explain the obligations.\",
  \"summary\": \"A 1-2 sentence extremely simple summary (EL15 - Explain Like I'm 5).\",
  \"key_concepts\": [
    {\"term\": \"Concept 1\", \"definition\": \"One short, clear sentence.\"},
    {\"term\": \"Concept 2\", \"definition\": \"One short, clear sentence.\"}
  ],
  \"why_matters\": \"A short paragraph explaining why this information is important or relevant.\",
  \"takeaways\": [\"Actionable item 1\", \"Actionable item 2\", \"Actionable item 3\"]
}
Instructions:
1.  **Detect Type**: Analyze inputs to identify one of: 'Code', 'Policy/Legal', 'Academic/Technical', 'General'.
2.  **Smart Handling**:
    - **Code**: Explain *what* the code does and *how* it works. Ignore minor syntax errors.
    - **Policy/Legal**: Focus on rights, obligations, compliance, and penalties.
    - **Academic/Technical**: Simplify jargon, explain theories/processes, and clarify complex concepts.
    - **General**: Focus on main ideas and simple takeaways.
3.  **Clear Explanation**: Provide a comprehensive but simple explanation.
4.  **No Repetition**: Ensure the Summary and Main Explanation are distinct.
5.  **Key Concepts**: Definitions must be ONE short sentence.
6.  **Tone**: Beginner-friendly, plain English, no legal or technical jargon.
7.  **Accuracy**: STRICTLY adhere to the input text. Do not add external assumptions.
8.  **Safety & Clarity Check**: If the input is nonsense, too massive to process, or purely profanity, return: `{\"error\": \"Input is unclear or invalid. Please provide meaningful text.\"}` inside the JSON.
STRICTLY return ONLY the valid JSON object, no markdown code blocks.";

// Construct Gemini API Request
$url = GEMINI_API_ENDPOINT . "?key=" . GEMINI_API_KEY;

$requestBody = [
    "contents" => [
        [
            "parts" => [
                ["text" => $systemPrompt . "\n\nInput Text:\n" . $userContent]
            ]
        ]
    ]
    // "generationConfig" removed to prevent 400 errors on endpoints that don't support response_mime_type
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestBody));

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if (curl_errno($ch)) {
    http_response_code(500);
    echo json_encode(['error' => 'Gemini API request failed: ' . curl_error($ch)]);
    curl_close($ch);
    exit;
}

curl_close($ch);

if ($httpCode !== 200) {
    http_response_code(500);
    echo json_encode(['error' => 'Gemini API returned error code: ' . $httpCode, 'details' => json_decode($response)]);
    exit;
}

// Parse Gemini Response
$decodedResponse = json_decode($response, true);
$aiText = $decodedResponse['candidates'][0]['content']['parts'][0]['text'] ?? null;

if (!$aiText) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to parse AI response.', 'raw_response' => $response]);
    exit;
}

// Cleanup: Remove markdown code blocks if present (Gemini might wrap JSON in ```json ... ```)
$aiText = preg_replace('/^```json\s*|\s*```$/', '', trim($aiText));

// Extract detected type for specific logging
$parsedAi = json_decode($aiText, true);
$detectedType = $parsedAi['detected_type'] ?? 'Unknown';

// Prepare data for database
$inputHash = hash('sha256', $userContent);
$truncatedContent = mb_substr($userContent, 0, 1000); // Store first 1000 chars

// Log to Database
try {
    $stmt = $pdo->prepare("INSERT INTO explanations (input_hash, input_content, content_type, ai_response) VALUES (:hash, :content, :type, :response)");
    $stmt->execute([
        ':hash' => $inputHash,
        ':content' => $truncatedContent,
        ':type' => $detectedType,
        ':response' => $aiText
    ]);
} catch (PDOException $e) {
    // Log error but generally proceed to return response to user
    error_log("Database Insert Error: " . $e->getMessage());
}

// Return the structured JSON to the frontend
echo $aiText;
