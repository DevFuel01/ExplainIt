-- Database Schema for ExplainIt AI

CREATE DATABASE IF NOT EXISTS explainit_ai;
USE explainit_ai;

CREATE TABLE IF NOT EXISTS explanations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    input_hash VARCHAR(64) NOT NULL, -- SHA-256 hash of input to prevent duplicate processing if needed
    input_content TEXT, -- Optional: store original content (truncated if too long)
    content_type VARCHAR(50), -- Detected type (Legal, Code, etc.)
    ai_response JSON, -- Store the full structured JSON response
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (input_hash)
);
