# ExplainIt AI

ExplainIt AI is a web-based tool that uses Google's Gemini AI to convert complex text, code, or legal documents into clear, structured, and human-friendly explanations. Designed for hackathons and quick deployment.

## Features

- **Simple & Clear UI**: Built with semantic HTML5 and modern CSS. "One action per screen" design philosophy.
- **AI-Powered**: Uses Google Gemini AI to analyze and simplify text into structured explanations.
- **Smart Handling**: Automatically detects legal documents, code, or technical text and tailors the explanation.
- **Robust Error Handling**: Handles API failures and invalid input gracefully. Shows user-friendly error messages.
- **Database Logging**: Stores input hashes, content type, and AI responses in MySQL for history/analytics.
- **Lightweight**: No heavy frontend frameworks, just Vanilla JS and PHP.

## Prerequisites

- **Web Server**: Apache (XAMPP/WAMP/MAMP recommended) or Nginx.
- **PHP**: Version 7.4 or higher with `curl` extension enabled.
- **MySQL**: Version 5.7 or higher.
- **Gemini API Key**: Get one from [Google AI Studio](https://aistudio.google.com/).

## Installation & Setup

1.  **Clone/Download**: Place the project files in your web server's root directory (e.g., `htdocs/ExplainIt`).
2.  **Database Setup**:
    - Open your MySQL tool (e.g., phpMyAdmin).
    - Create a new database named `explainit_ai` (or just run the schema script).
    - Import `database_schema.sql` to create the necessary table.
3.  **Configuration**:
    - Open `api/config.php`.
    - Update `DB_USER`, `DB_PASS` if your MySQL credentials differ from the default.
    - **CRITICAL**: Replace `'YOUR_API_KEY_HERE'` with your actual Gemini API Key.
4.  **Run**:
    - Open your browser and navigate to `http://localhost/ExplainIt/`.

## Usage

1.  Paste complex text into the text area.
2.  Click "Explain This".
3.  Wait for the AI to process (usually 2-5 seconds).
4.  Read the simplified explanation below.

## Project Structure

```
ExplainIt/
├── api/
│   ├── config.php       # Database & API configuration
│   └── explain.php      # Core backend logic (API endpoint)
├── database_schema.sql  # SQL script to create the database
├── index.html           # Main user interface
├── main.js              # Frontend logic (AJAX, DOM manipulation)
├── style.css            # Styles/CSS
└── README.md            # You are here
```

## Security Note

This is a demo/hackathon project. For production:
- Store API keys in environment variables, not in `config.php`.
- Implement robust rate limiting.
- Add user authentication.

## System Architecture

1.  **Frontend (HTML/JS)**: Captures input, visualizes the detected content type, and handles API communication.
2.  **Backend (PHP)**:
    -   `api/explain.php`: Acts as the orchestrator. Validates input, constructs the AI prompt, and manages the Gemini API interaction.
    -   `api/config.php`: Centralized configuration.
3.  **AI Engine (Gemini)**: Processes the text based on the "Intelligent Prompt" strategy.
4.  **Database (MySQL)**: Logs every interaction (Input Hash, Content Type, Response) for analytics.

## Prompt Strategy

ExplainIt AI uses a **Context-Aware Prompting** strategy. The system:
-   **Detects Content Type**: Dynamically adjusts its explanation style for Code, Legal, Technical, or General text.
-   **Enforces Structure**: Strictly demands a JSON response with specific keys (`summary`, `key_concepts`, etc.).
-   **Safety Checks**: identifies and gracefully refuses nonsensical or inappropriate inputs.

## API Usage

**Endpoint**: `POST /api/explain.php`

**Request Body**:
```json
{
  "content": "Your complex text here..."
}
```

**Response**:
```json
{
  "detected_type": "Legal Document",
  "main_explanation": "...",
  "summary": "...",
  "key_concepts": [...],
  "why_matters": "...",
  "takeaways": [...]
}
```

## License

MIT License.
