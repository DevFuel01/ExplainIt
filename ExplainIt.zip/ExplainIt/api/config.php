<?php
// api/config.php

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'explainit_ai');
define('DB_USER', 'root');
define('DB_PASS', '');

// Google Gemini API Key
// IMPORTANT: Repalce 'YOUR_API_KEY_HERE' with your actual API key.
// Ideally, this should be stored in an environment variable or a separate file outside the web root.
// For hackathon purposes, we define it here for simplicity.
define('GEMINI_API_KEY', '');
define('GEMINI_API_ENDPOINT', 'https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent');

// Establish Database Connection
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("set names utf8");
} catch (PDOException $e) {
    // Return error as JSON if connection fails
    header('Content-Type: application/json');
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]);
    exit;
}
